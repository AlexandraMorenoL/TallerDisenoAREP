
package co.edu.eci.mathproxy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MathProxyApplication {
    public static void main(String[] args) {
        SpringApplication.run(MathProxyApplication.class, args);
    }
}
