
package co.edu.eci.mathservice;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MathController {

    @GetMapping("/api/health")
    public String health() {
        return "OK";
    }

    @GetMapping("/api/fib")
    public long fibonacci(@RequestParam("n") int n) {
        if (n < 0 || n > 92) { // prevent long overflow
            throw new IllegalArgumentException("n must be in [0,92]");
        }
        long a = 0, b = 1;
        for (int i = 0; i < n; i++) {
            long tmp = a + b;
            a = b;
            b = tmp;
        }
        return a;
    }

    @GetMapping("/api/fact")
    public long factorial(@RequestParam("n") int n) {
        if (n < 0 || n > 20) { // prevent long overflow
            throw new IllegalArgumentException("n must be in [0,20]");
        }
        long res = 1;
        for (int i = 2; i <= n; i++) res *= i;
        return res;
    }

    @GetMapping("/api/isPrime")
    public boolean isPrime(@RequestParam("n") long n) {
        if (n < 2) return false;
        if (n % 2 == 0) return n == 2;
        long limit = (long) Math.sqrt(n);
        for (long d = 3; d <= limit; d += 2) {
            if (n % d == 0) return false;
        }
        return true;
    }
}
