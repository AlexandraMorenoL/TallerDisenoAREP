
# Microservicios Matemáticos en AWS — Spring Boot + Proxy round‑robin

**Tecnologías**: Maven, Git, GitHub, Spring Boot, HTML5 y JS (sin librerías).  
**Arquitectura**: 1 Proxy (round‑robin) + 2 instancias de **math-service** (EC2) + cliente web asíncrono (HTML/JS) que invoca el **PROXY**.

> Todo el código es simple, original y sin dependencias adicionales al *starter web* de Spring. El cliente no usa librerías JS.

## Estructura del repositorio

```
.
├─ proxy/                 # Spring Boot: proxy HTTP con balanceo round‑robin
│  └─ src/main/resources/static/index.html  # Cliente HTML+JS
├─ math-service/          # Spring Boot: funciones numéricas
└─ README.md
```

---

## ¿Qué hace cada componente?

### 1) `math-service`
Servicio REST con 3 endpoints (GET) bajo `/api/*`:

- `/api/fib?n=<0..92>` → devuelve F(n) (iterativo, evita overflow de `long`)
- `/api/fact?n=<0..20>` → devuelve n!
- `/api/isPrime?n=<n>` → primalidad (prueba determinista simple hasta √n)

> **Puertos**: por defecto `8081`. Puede sobrescribir con `SERVER_PORT`.

### 2) `proxy`
Expone los mismos endpoints `/api/fib`, `/api/fact`, `/api/isPrime` y **reenvía** a una de las instancias `math-service` usando **round‑robin**.
- **Targets**: defínalos con la variable de entorno `MATH_TARGETS`, coma‑separados, por ejemplo:
  ```
  MATH_TARGETS="http://10.0.1.10:8081,http://10.0.2.20:8081"
  ```
  Si no se define, usa `http://localhost:8081` (útil en desarrollo local).
- Implementa el reenvío con `HttpURLConnection` (API Java SE), sin librerías extra.
- Endpoints extra:
  - `/api/health` → `"OK"`
  - `/api/targets` → lista los targets activos (texto plano).

### 3) Cliente (HTML + JS puro)
Archivo `proxy/src/main/resources/static/index.html`. Al iniciar el proxy se sirve en `http://HOST:8080/`.
- Envía solicitudes **asíncronas** (XHR) al **proxy**.
- Formulario para cada función (Fibonacci, Factorial, Primalidad).
- Muestra la respuesta en pantalla.

---

## Cómo compilar y probar **localmente** (Windows, macOS o Linux)

Requisitos:
- Java 17 (p. ej. Amazon Corretto 17).
- Maven 3.8+.
- Git (opcional para clonado).

### 0) Verificar versiones
```bash
java -version
mvn -v
```

### 1) Compilar ambos módulos
```bash
cd math-service
mvn -q clean package
cd ../proxy
mvn -q clean package
```

### 2) Levantar **dos** instancias de `math-service` en **puertos distintos**
Terminal A:
```bash
cd math-service
java -jar target/math-service-0.0.1-SNAPSHOT.jar --server.port=8081
```
Terminal B:
```bash
cd math-service
java -jar target/math-service-0.0.1-SNAPSHOT.jar --server.port=8082
```

### 3) Levantar el **proxy** apuntando a las dos instancias
```bash
cd proxy
# Windows (CMD):
set MATH_TARGETS=http://localhost:8081,http://localhost:8082
# PowerShell:
$env:MATH_TARGETS="http://localhost:8081,http://localhost:8082"
# Linux/macOS:
export MATH_TARGETS="http://localhost:8081,http://localhost:8082"

java -jar target/math-proxy-0.0.1-SNAPSHOT.jar --server.port=8080
```

### 4) Probar desde el navegador
Abra: `http://localhost:8080/`  
Pruebe los formularios. También puede invocar directo:
```
http://localhost:8080/api/fib?n=10
http://localhost:8080/api/fact?n=10
http://localhost:8080/api/isPrime?n=97
http://localhost:8080/api/targets
```

> Si detiene una instancia de `math-service`, las llamadas alternarán entre la viva y la caída. Verá el mensaje `"Upstream error (XXX): ..."`. En despliegue se recomienda correr ambas siempre.

---

## Despliegue en **AWS EC2** (mínimo viable)

> Este es un **paso a paso genérico** para Amazon Linux 2023 (o Amazon Linux 2). Adáptelo a su VPC/SGs.

### 1) Crear 3 instancias EC2
- **2×** para `math-service` (ej. `MS1` y `MS2`)
- **1×** para `proxy` (ej. `PROXY`)
- Security Groups:
  - `MS1/MS2`: permitir **TCP 8081** (y/o 8082) **desde** el SG del proxy (no abierto a Internet).
  - `PROXY`: permitir **TCP 8080** desde su IP (o 0.0.0.0/0 solo para pruebas).

### 2) Instalar Java y Maven
```bash
# En cada instancia (MS1, MS2, PROXY)
sudo yum update -y
sudo yum install -y java-17-amazon-corretto maven git
java -version
mvn -v
```

### 3) Desplegar **math-service** en MS1 y MS2
En ambas (cambie puerto para la segunda):
```bash
git clone <SU_REPO_GITHUB>.git app
cd app/math-service
mvn -q clean package

# MS1
nohup java -jar target/math-service-0.0.1-SNAPSHOT.jar --server.port=8081 > app.log 2>&1 &

# MS2 (puede usar mismo puerto si está en otra VM; si decide usar 8082, ajústelo)
nohup java -jar target/math-service-0.0.1-SNAPSHOT.jar --server.port=8081 > app.log 2>&1 &
```

Compruebe salud (desde cada VM):
```bash
curl -s http://localhost:8081/api/health
```

### 4) Desplegar **proxy** en PROXY
```bash
git clone <SU_REPO_GITHUB>.git app
cd app/proxy
mvn -q clean package

# Ajuste las IP privadas de MS1 y MS2 dentro de la misma VPC:
export MATH_TARGETS="http://10.0.1.10:8081,http://10.0.2.20:8081"
# (reemplácelo por las IP privadas reales)

nohup java -jar target/math-proxy-0.0.1-SNAPSHOT.jar --server.port=8080 > app.log 2>&1 &
```

Pruebe desde su equipo (IP pública del PROXY):
```
http://<IP_PUBLICA_PROXY>:8080/
```

> Consejo: para persistencia al reinicio use `systemd` o un script de arranque. **No** se incluyen aquí para mantener el entregable mínimo y 100% original.

---

## Decisiones de diseño

- **Round‑robin simple** basado en `AtomicInteger` → sin estado compartido ni librerías externas.
- **`HttpURLConnection`** (Java SE) para reenvío → cumple la restricción de no usar clientes externos.
- **Límites de cálculo**: se fijan cotas para evitar overflow de `long` (Fibonacci ≤ 92, Factorial ≤ 20).
- **Cliente estático** servido por el **proxy** para evitar CORS y simplificar despliegue.
- **Configuración por variables de entorno** (`MATH_TARGETS`, `SERVER_PORT`) como pide el enunciado.

---

## Comandos rápidos (chuleta)

```bash
# Compilar todo
(cd math-service && mvn -q clean package)
(cd proxy && mvn -q clean package)

# Ejecutar dos math-service locales
java -jar math-service/target/math-service-0.0.1-SNAPSHOT.jar --server.port=8081
java -jar math-service/target/math-service-0.0.1-SNAPSHOT.jar --server.port=8082

# Proxy apuntando a ambas
export MATH_TARGETS="http://localhost:8081,http://localhost:8082"
java -jar proxy/target/math-proxy-0.0.1-SNAPSHOT.jar --server.port=8080
```

---

## Pruebas manuales (curl)

```bash
# vía proxy (balanceadas)
curl "http://localhost:8080/api/fib?n=25"
curl "http://localhost:8080/api/fact?n=10"
curl "http://localhost:8080/api/isPrime?n=97"
curl "http://localhost:8080/api/targets"

# salud directa (si tiene acceso a MS1/MS2)
curl "http://IP_PRIVADA_MS1:8081/api/health"
```

---

## Notas de originalidad y cumplimiento

- Sin librerías adicionales: solo `spring-boot-starter-web`.
- Cliente **HTML/JS** sin frameworks.
- Configuración por env vars como lo exige el problema.
- Código claro, autocontenido y comentado solo donde es esencial (la documentación está **aquí**).
