
# Microservicios Matemáticos en AWS — Spring Boot + Proxy round-robin

**Tecnologías**: Maven, Git, GitHub, Spring Boot, HTML5 y JS (sin librerías).  
**Arquitectura**: 1 Proxy (round-robin) + 2 instancias de **math-service** (EC2) + cliente web asíncrono (HTML/JS) que invoca el **PROXY**.

> Todo el código es simple, original y sin dependencias adicionales al *starter web* de Spring. El cliente no usa librerías JS.

## Estructura del repositorio

```
.
├─ proxy/                 # Spring Boot: proxy HTTP con balanceo round-robin
│  └─ src/main/resources/static/index.html  # Cliente HTML+JS
├─ math-service/          # Spring Boot: funciones numéricas y algoritmos de búsqueda
└─ README.md
```

---

## Servicios expuestos

### `math-service` (puerto 8081 por defecto)

- `/api/health` → `"OK"`
- `/api/fib?n=<0..92>` → F(n) (iterativo)
- `/api/fact?n=<0..20>` → n!
- `/api/isPrime?n=<n>` → primalidad
- `/linearsearch?list=<csv>&value=<v>` → **búsqueda lineal** en lista de **cadenas** (exact match). Respuesta JSON.
- `/binarysearch?list=<csv>&value=<v>` → **búsqueda binaria recursiva** en lista **ordenada** (lexicográfica). Respuesta JSON.

**Formato JSON de búsqueda**:
```json
{ "operation": "<linearSearch|binarySearch>", "inputlist": "<csv>", "value": "<valor>", "output": "<indice o -1>" }
```

### `proxy` (puerto 8080 por defecto)
- Replica los endpoints anteriores y **reenvía** con **round-robin** a las instancias de `math-service` usando `HttpURLConnection`.
- Configuración por variable de entorno:
```
MATH_TARGETS="http://10.0.1.10:8081,http://10.0.2.20:8081"
```
- Endpoints extra: `/api/targets`, `/api/health`.

El cliente HTML+JS está servido en `http://HOST:8080/`.

---

## Cómo compilar y correr localmente

Requisitos: Java 17, Maven 3.8+.

```bash
# Compilar
(cd math-service && mvn -q clean package)
(cd proxy && mvn -q clean package)

# Ejecutar dos instancias del math-service
java -jar math-service/target/math-service-0.0.1-SNAPSHOT.jar --server.port=8081
java -jar math-service/target/math-service-0.0.1-SNAPSHOT.jar --server.port=8082

# Levantar el proxy apuntando a ambas
# Linux/macOS
export MATH_TARGETS="http://localhost:8081,http://localhost:8082"
# Windows PowerShell
$env:MATH_TARGETS="http://localhost:8081,http://localhost:8082"
java -jar proxy/target/math-proxy-0.0.1-SNAPSHOT.jar --server.port=8080
```

### Pruebas
- Navegador: `http://localhost:8080/`
- Curl (vía proxy):
```
http://localhost:8080/linearsearch?list=10,20,13,40,60&value=13
http://localhost:8080/linearsearch?list=10,20,13,40,60&value=99
http://localhost:8080/binarysearch?list=10,13,20,40,60&value=13
```

---

## Despliegue mínimo en AWS EC2

1. Cree **3** instancias (2× `math-service`, 1× `proxy`), todas con Java 17 y Maven.
2. **Security Groups**: exponga 8080 en `proxy` y permita que `proxy` acceda a 8081 en las VMs de servicio.
3. Despliegue en cada VM:
```bash
# En MS1 y MS2
git clone <SU_REPO_GITHUB>.git app && cd app/math-service
mvn -q clean package
nohup java -jar target/math-service-0.0.1-SNAPSHOT.jar --server.port=8081 > app.log 2>&1 &

# En PROXY
git clone <SU_REPO_GITHUB>.git app && cd app/proxy
mvn -q clean package
export MATH_TARGETS="http://<IP_PRIVADA_MS1>:8081,http://<IP_PRIVADA_MS2>:8081"
nohup java -jar target/math-proxy-0.0.1-SNAPSHOT.jar --server.port=8080 > app.log 2>&1 &
```
4. Pruebe: `http://<IP_PUBLICA_PROXY>:8080/`

---

## Algoritmos (explicación breve)

- **Búsqueda lineal**: recorre de izquierda a derecha comparando cada elemento con `value` y retorna el **primer índice** o `-1` si no está.
- **Búsqueda binaria (recursiva)**: sobre lista **ordenada**; calcula `mid`, compara y reduce el rango a la mitad. Si encuentra coincidencia, retrocede para reportar la **primera** ocurrencia.

---

## Cumplimiento

- Sin librerías externas (solo Spring Web).  
- Cliente HTML+JS puro.  
- Configuración por variables de entorno en el proxy.
